# Трекер привычек

Сгенерировано bildo (AppDocument → Expo).

## Запуск

```bash
npm install
npx expo start
```

Отсканируйте QR в **Expo Go** (iOS/Android) или нажмите `w` для web.

Промпт: трекер привычек
