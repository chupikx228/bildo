export const theme = {
  "colorBg": "#FBFBFC",
  "colorSurface": "#FFFFFF",
  "colorBorder": "#E8E8EE",
  "colorText": "#101014",
  "colorTextMuted": "#5B5B66",
  "colorPrimary": "#16A34A",
  "colorPrimaryFg": "#FFFFFF",
  "radiusBase": "14",
  "fontBody": "Inter",
  "fontHeading": "Inter"
} as const;
