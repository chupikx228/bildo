import { Tabs } from 'expo-router';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppStateProvider } from './state';
import { theme } from '../theme';

export default function Layout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppStateProvider>
          <Tabs
            screenOptions={{
              headerStyle: { backgroundColor: theme.colorSurface },
              headerTintColor: theme.colorText,
              tabBarStyle: { backgroundColor: theme.colorSurface, borderTopColor: theme.colorBorder },
              tabBarActiveTintColor: theme.colorPrimary,
              tabBarInactiveTintColor: theme.colorTextMuted,
              sceneStyle: { backgroundColor: theme.colorBg },
            }}
          >
            <Tabs.Screen name="index" options={{ title: 'Сегодня' }} />
            <Tabs.Screen name="progress" options={{ title: 'Прогресс' }} />
          </Tabs>
        </AppStateProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
