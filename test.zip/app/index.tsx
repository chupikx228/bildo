import { Alert, Pressable, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { theme } from '../theme';
import { useAppState } from './state';

export default function IndexScreen() {
  const router = useRouter();
  const { state, setVar } = useAppState();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.colorBg }} edges={['top', 'left', 'right']}>
      <StatusBar style="auto" />
    <View style={{
  flex: 1,
  backgroundColor: '#FBFBFC'
}}>
      <Text style={{
  position: 'absolute',
  left: 24,
  top: 88,
  width: 200,
  height: 36,
  color: '#101014',
  fontSize: 26,
  fontWeight: '700'
}}>Сегодня</Text>
      <Text style={{
  position: 'absolute',
  left: 24,
  top: 126,
  width: 240,
  height: 22,
  color: '#5B5B66',
  fontSize: 13,
  fontWeight: '400'
}}>Серия дней подряд</Text>
      <View style={{
  position: 'absolute',
  left: 24,
  top: 168,
  width: 322,
  height: 96,
  padding: 14,
  backgroundColor: '#FFFFFF',
  borderRadius: 16,
  borderWidth: 1,
  borderColor: '#E8E8EE'
}}>
        <Text style={{
  position: 'absolute',
  left: 14,
  top: 14,
  width: 180,
  height: 24,
  color: '#101014',
  fontSize: 16,
  fontWeight: '600'
}}>Пить воду</Text>
        <Text style={{
  position: 'absolute',
  left: 14,
  top: 40,
  width: 200,
  height: 20,
  color: '#5B5B66',
  fontSize: 13,
  fontWeight: '400'
}}>8 стаканов в день</Text>
        <Pressable style={{
  position: 'absolute',
  left: 206,
  top: 26,
  width: 100,
  height: 44,
  backgroundColor: '#16A34A',
  color: '#FFFFFF',
  fontSize: 14,
  fontWeight: '600',
  textAlign: 'center',
  borderRadius: 12
}} onPress={() => {
    setVar('completedToday', 1);
    Alert.alert('', 'Привычка отмечена');
  }}>
          <Text style={{ color: theme.colorPrimaryFg, fontWeight: '600', textAlign: 'center' }}>Готово</Text>
        </Pressable>
      </View>
      <View style={{
  position: 'absolute',
  left: 24,
  top: 280,
  width: 322,
  height: 96,
  padding: 14,
  backgroundColor: '#FFFFFF',
  borderRadius: 16,
  borderWidth: 1,
  borderColor: '#E8E8EE'
}}>
        <Text style={{
  position: 'absolute',
  left: 14,
  top: 14,
  width: 180,
  height: 24,
  color: '#101014',
  fontSize: 16,
  fontWeight: '600'
}}>Чтение</Text>
        <Text style={{
  position: 'absolute',
  left: 14,
  top: 40,
  width: 200,
  height: 20,
  color: '#5B5B66',
  fontSize: 13,
  fontWeight: '400'
}}>20 минут перед сном</Text>
        <Pressable style={{
  position: 'absolute',
  left: 206,
  top: 26,
  width: 100,
  height: 44,
  backgroundColor: '#16A34A',
  color: '#FFFFFF',
  fontSize: 14,
  fontWeight: '600',
  textAlign: 'center',
  borderRadius: 12
}} onPress={() => {
    setVar('completedToday', 2);
    Alert.alert('', 'Привычка отмечена');
  }}>
          <Text style={{ color: theme.colorPrimaryFg, fontWeight: '600', textAlign: 'center' }}>Готово</Text>
        </Pressable>
      </View>
      <Pressable style={{
  position: 'absolute',
  left: 24,
  top: 404,
  width: 322,
  height: 48,
  backgroundColor: '#16A34A',
  color: '#FFFFFF',
  fontSize: 14,
  fontWeight: '600',
  textAlign: 'center',
  borderRadius: 12
}} onPress={() => {
    router.push('/progress');
  }}>
        <Text style={{ color: theme.colorPrimaryFg, fontWeight: '600', textAlign: 'center' }}>Прогресс</Text>
      </Pressable>
    </View>
    </SafeAreaView>
  );
}
