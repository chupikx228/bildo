import React, { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

type Vars = Record<string, string | number | boolean>;

type CtxValue = {
  state: Vars;
  setVar: (k: string, v: string | number | boolean) => void;
};

const Ctx = createContext<CtxValue | null>(null);

const initial: Vars = {
  "completedToday": 0
};

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Vars>(initial);
  const setVar = useCallback((k: string, v: string | number | boolean) => {
    setState(s => ({ ...s, [k]: v }));
  }, []);
  const value = useMemo(() => ({ state, setVar }), [state, setVar]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAppState(): CtxValue {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useAppState must be used within AppStateProvider');
  return ctx;
}
