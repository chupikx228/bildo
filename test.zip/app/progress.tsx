import { Pressable, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { theme } from '../theme';
import { useAppState } from './state';

export default function ProgressScreen() {
  const router = useRouter();
  const { state, setVar } = useAppState();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.colorBg }} edges={['top', 'left', 'right']}>
      <StatusBar style="auto" />
    <View style={{
  flex: 1,
  backgroundColor: '#FBFBFC'
}}>
      <Text style={{
  position: 'absolute',
  left: 24,
  top: 88,
  width: 240,
  height: 36,
  color: '#101014',
  fontSize: 26,
  fontWeight: '700'
}}>Прогресс</Text>
      <View style={{
  position: 'absolute',
  left: 24,
  top: 140,
  width: 322,
  height: 120,
  padding: 14,
  backgroundColor: '#FFFFFF',
  borderRadius: 16,
  borderWidth: 1,
  borderColor: '#E8E8EE'
}}>
        <Text style={{
  position: 'absolute',
  left: 14,
  top: 14,
  width: 240,
  height: 22,
  color: '#5B5B66',
  fontSize: 13,
  fontWeight: '400'
}}>Выполнено сегодня</Text>
        <Text style={{
  position: 'absolute',
  left: 14,
  top: 44,
  width: 200,
  height: 52,
  color: '#16A34A',
  fontSize: 40,
  fontWeight: '700'
}}>{String(state['completedToday'] ?? '')}</Text>
      </View>
      <Pressable style={{
  position: 'absolute',
  left: 24,
  top: 284,
  width: 322,
  height: 48,
  backgroundColor: '#16A34A',
  color: '#FFFFFF',
  fontSize: 14,
  fontWeight: '600',
  textAlign: 'center',
  borderRadius: 12
}} onPress={() => {
    router.push('/');
  }}>
        <Text style={{ color: theme.colorPrimaryFg, fontWeight: '600', textAlign: 'center' }}>Привычки</Text>
      </Pressable>
    </View>
    </SafeAreaView>
  );
}
